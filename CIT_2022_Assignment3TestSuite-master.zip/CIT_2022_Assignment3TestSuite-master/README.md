This is a modified version which do not use the JsonSerializerOptions. 
